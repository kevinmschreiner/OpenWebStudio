﻿if (!String.prototype.splice) {
    String.prototype.splice = function(start, delCount, newSubStr) {
        return this.slice(0, start) + newSubStr + this.slice(start + Math.abs(delCount));
    };
}

//OVERRIDE BASE 
window.base_onActionLoad_File = window.onActionLoad_File;
window.base_onfrmDestinationType_Toggle = window.onfrmDestinationType_Toggle;
window.base_onfrmSourceType_Toggle = window.onfrmSourceType_Toggle;
window.base_onActionSave_File = window.onActionSave_File;

for (var i = 0; i < sysAction_Types.length; i++) {
	if (sysAction_Types[i].Code == "Action-File") {
		var t = sysAction_Types[i].Template+"";
		var source = "<tr>" +
			"<td class=SubHead width=151><div id=fo1>Source Username</div></td>" +
			"<td><div id=fo2><input name=frmSourceUsername id=frmSourceUsername type=textbox style=\"width:100%;\"></div></td>" +
			"</tr>" +
			"<tr>" +
			"<td class=SubHead width=151>" +
			"<div id=fo3>Source Password</div></td>" +
			"<td><div id=fo4><input name=frmSourcePassword id=frmSourcePassword type=textbox style=\"width:100%;\"></div></td>" +
			"</tr>";
		var destination = "<tr>" +
			"<td class=SubHead width=151><div id=fo5>Destination Username</div></td>" +
			"<td><div id=fo6><input name=frmDestinationUsername id=frmDestinationUsername type=textbox style=\"width:100%;\"></div></td>" +
			"</tr>" +
			"<tr>" +
			"<td class=SubHead width=151>" +
			"<div id=fo7>Destination Password</div></td>" +
			"<td><div id=fo8><input name=frmDestinationPassword id=frmDestinationPassword type=textbox style=\"width:100%;\"></div></td>" +
			"</tr>"
			;
		t = t.splice(t.indexOf("</select>",t.indexOf("frmSourceType")),0,"<option value=\"SFTP\">SFTP Server</option>");
		t = t.splice(t.indexOf("</select>",t.indexOf("frmDestinationType")),0,"<option value=\"SFTP\">SFTP Server</option>");
		t = t.splice(t.indexOf("</tr>",t.indexOf("id=frmSource "))+5,0,source);
		t = t.splice(t.indexOf("</tr>",t.indexOf("id=frmDestination "))+5,0,destination);
		
		sysAction_Types[i].Template = t;
		i = sysAction_Types.length + 1;
	}
}
function onClick_Actions_File() {
	//ADD A NEW ACTION
	AddAction("Action-File", { "SourceType": "", "SourceVariableType": "", "Source": "", "SourceUsername":"","SourcePassword":"", "SourceQuery": "", "SourceConnection": "", "DestinationType": "", "DestinationVariableType": "", "DestinationResponseType": "", "SQLFirstRow": "False", "ColumnMappings": "", "DestinationQuery": "", "RunAsProcess": "False", "ProcessName": "", "Destination": "", "DestinationUsername":"","DestinationPassword":"", "TransformType": "", "ImageTransformType": "", "ImageFont": "", "ImageSize": "", "ImageSizeType": "", "ImageColor": "", "ImageBGColor": "", "ImageWidth": "", "ImageWidthType": "px", "ImageRotation": "", "ImageHeight": "", "ImageHeightType": "px", "ImageQuality": "90", "XMLReadPath": "", "XMLWritePath": "", "FileTask": "" });
}

window.onActionLoad_File=function(template, action) {
	currentFileAction = action;
	//add additional values
	sysSetText($('frmSourceUsername'), action.Parameters.SourceUsername);
	sysSetText($('frmSourcePassword'), action.Parameters.SourcePassword);
	sysSetText($('frmDestinationUsername'), action.Parameters.DestinationUsername);
	sysSetText($('frmDestinationPassword'), action.Parameters.DestinationPassword);

	//call base function
	window.base_onActionLoad_File(template, action);
}
window.onfrmDestinationType_Toggle=function() {
	vmeth = $('frmDestinationType');
	switch (sysGetSelect(vmeth).toLowerCase()) {
		case 'sftp':
			//same as path
			hideBlock($('fi6')); hideBlock($('fi7')); hideBlock($('fi8')); hideBlock($('fi9')); hideBlock($('fi10')); hideBlock($('fi11'));
			hideBlock($('fi12')); hideBlock($('fi13')); hideBlock($('fi14')); hideBlock($('fi15')); hideBlock($('fi16')); hideBlock($('fi17'));
			//authentication
			showBlock($('fo5')); showBlock($('fo6')); showBlock($('fo7')); showBlock($('fo8'));
			break;
		default:
			hideBlock($('fo5')); hideBlock($('fo6')); hideBlock($('fo7')); hideBlock($('fo8'));
			break;
	}
	base_onfrmDestinationType_Toggle();
}
window.onfrmSourceType_Toggle=function() {
	vmeth = $('frmSourceType');
	switch (sysGetSelect(vmeth).toLowerCase()) {
		case 'sftp':
			//same as path
			hideBlock($('fi0')); hideBlock($('fi1')); showBlock($('fi2')); showBlock($('fi3')); hideBlock($('fi4')); hideBlock($('fi5')); hideBlock($('fy4')); hideBlock($('fy5'));
			//authentication
			showBlock($('fo1')); showBlock($('fo2')); showBlock($('fo3')); showBlock($('fo4'));
			break;
		default:
			hideBlock($('fo1')); hideBlock($('fo2')); hideBlock($('fo3')); hideBlock($('fo4'));
			break;
	}
	base_onfrmSourceType_Toggle();
}

window.onActionSave_File=function(template, action) {
	action.Parameters.SourceUsername = sysGetText($('frmSourceUsername'));
	action.Parameters.SourcePassword = sysGetText($('frmSourcePassword'));
	action.Parameters.DestinationUsername = sysGetText($('frmDestinationUsername'));
	action.Parameters.DestinationPassword = sysGetText($('frmDestinationPassword'));
	return base_onActionSave_File(template,action);
}


