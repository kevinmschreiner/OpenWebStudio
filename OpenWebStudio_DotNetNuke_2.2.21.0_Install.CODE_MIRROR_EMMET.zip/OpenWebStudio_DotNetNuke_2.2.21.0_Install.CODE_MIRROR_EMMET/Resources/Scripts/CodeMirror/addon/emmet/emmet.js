import emmet from 'emmet';
import 'emmet/bundles/snippets';
import 'emmet/bundles/caniuse';

export default emmet;